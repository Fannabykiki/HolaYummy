package com.example.holayummy.Interface;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view, int pos, boolean isLongClick);
}
